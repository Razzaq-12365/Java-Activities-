package com.java.Lib.lib.dao;

import com.java.Lib.lib.entity.Book;

public interface BookDao {
	public void insertRecord(Book b);
}
