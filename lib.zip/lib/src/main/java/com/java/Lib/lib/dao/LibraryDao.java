package com.java.Lib.lib.dao;

import com.java.Lib.lib.entity.Library;

public interface LibraryDao {
 public void insertLib(Library lib);	
}
